#include "client_view.h"

#include <stdio.h>
#include <stdlib.h>

 
