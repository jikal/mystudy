#ifndef _CLIENT_VIEW_H_
#define _CLIENT_VIEW_H_

 
#endif
