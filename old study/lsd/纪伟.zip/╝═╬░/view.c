//显示函数
#include <stdio.h>
#include <string.h>
#include "view.h"
#include "model.h"
#include<stdlib.h>
void welcomeMenu(void){
	system("clear");
	printf("\t\t\t**************************\t\t\t\n");
	printf("\t\t\t* 欢迎进入网络聊天系统 *\t\t\t\n");
	printf("\t\t\t* 版本：v1.0 版权：纪伟 *\t\t\t\n");
	printf("\t\t\t****************************\t\t\t\n\n");
}
